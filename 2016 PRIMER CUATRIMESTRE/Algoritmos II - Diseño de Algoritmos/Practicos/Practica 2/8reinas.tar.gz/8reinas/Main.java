/**
 * Main class of the Java program. 
 * 
 */

public class Main {

    public static void main(String[] args) {
       
       OchoReinas ochoReinas = new OchoReinas();
       System.out.println("Solucion al problema de las ocho reinas: \n" + ochoReinas.obtenerSolucionOchoReinas().toString());
       
    }
}
