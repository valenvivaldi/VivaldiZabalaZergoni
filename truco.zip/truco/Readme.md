# Truco Project

Este es un proyecto para la asignatura "Análisis y Diseño de Sistemas" 

### Install

 `npm install`


### Run

 `npm test`

### Useful Links
[Mocha](https://mochajs.org)
[Chai API](http://chaijs.com/api/bdd/)
[Lodash](https://lodash.com/docs)

