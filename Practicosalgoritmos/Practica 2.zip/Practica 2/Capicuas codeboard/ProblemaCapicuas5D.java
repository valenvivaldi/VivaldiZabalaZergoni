import java.util.List;

/**
 * Clase que resuelve el problema de los numeros capicuas.
 * <p>
 * Una solucion a este problema consiste en un par (a,b) tal que a y b son numeros capicuas de 5 digitos tal que no exista
 * otro par (c,d) de numeros capicuas de 5 digitos tal que |c - d| < |a - b|.
 * 
*/
public class ProblemaCapicuas5D {
    
    /**
     * @return todas las soluciones posibles al problema que plantea esta clase
     */ 
    public static List<ParCapicuas> obtenerSoluciones() {
        throw new UnsupportedOperationException("ProblemaCapicuas5D#obtenerSoluciones() : no implementado");
    }
    
    /**
    * @return una solucion al problema que plantea esta clase
    */ 
    public static ParCapicuas obtenerSolucion() {
        throw new UnsupportedOperationException("ProblemaCapicuas5D#obtenerSolucion() : no implementado");
    }
    
    
}
